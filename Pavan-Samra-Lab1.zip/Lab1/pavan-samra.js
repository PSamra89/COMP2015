/*
Name: Pavan Samra
Student ID: A00891410
 */

var birdImage = document.getElementById("bird");
var catImage = document.getElementById("cat");

birdImage.width = catImage.width;